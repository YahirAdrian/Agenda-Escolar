# Agenda-Escolar
Es una página web de una agenda de clases para mi grupo 5AMPR para poder ayudar a mis compañeros en las clases en línea informandolos de las tareas pendientes y las renuiones del día siguiente como si fuera una agenda.
